const searchBox = document.getElementById('searchBox');
const packages = document.querySelectorAll('.package');
const noResults = document.getElementById('noResults');
const copyButtons = document.querySelectorAll('.copy-btn');

searchBox.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase().trim();
    let visibleCount = 0;

    packages.forEach(function(pkg) {
        const searchData = pkg.getAttribute('data-search').toLowerCase();
        if (searchData.includes(searchTerm)) {
          pkg.classList.remove('hidden');
          visibleCount++;
        } else {
          pkg.classList.add('hidden');
        }
      });

      if (visibleCount === 0) {
        noResults.classList.add('show');
      } else {
        noResults.classList.remove('show');
      }
});

copyButtons.forEach(function(button) {
    button.addEventListener('click', function() {
    const valueCell = this.previousElementSibling.previousElementSibling;
    const valueToCopy = valueCell.getAttribute('data-value');
        
    navigator.clipboard.writeText(valueToCopy).then(function() {
        button.textContent = '✓';
        button.classList.add('copied'); //rework to delete class from memory
          
        setTimeout(function() {
            button.textContent = 'Copy';
            button.classList.remove('copied');
            }, 1500);
        }).catch(function(err) { //TODO: unit testing
            console.error('Failed to copy:', err);
        });
    });
});